rdflib.plugins.shared package
=============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   rdflib.plugins.shared.jsonld

Module contents
---------------

.. automodule:: rdflib.plugins.shared
   :members:
   :undoc-members:
   :show-inheritance:
